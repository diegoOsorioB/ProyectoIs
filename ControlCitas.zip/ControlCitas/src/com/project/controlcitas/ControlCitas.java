package com.project.controlcitas;

import com.project.controlcitas.GUI.FrmLogin;

public class ControlCitas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FrmLogin frmLogin = new FrmLogin();
        frmLogin.setLocationRelativeTo(null);
        frmLogin.setVisible(true);
    }

}
